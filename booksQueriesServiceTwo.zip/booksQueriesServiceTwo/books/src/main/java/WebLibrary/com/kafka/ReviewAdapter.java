package WebLibrary.com.kafka;

public class ReviewAdapter {
//    public static Review gerReviewFromReviewDto(ReviewDTO reviewDto){
//       return new Review(reviewDto.getReviewId(), reviewDto.getDescription());
//    }
//    public static ReviewDTO gerReviewDtoFromReviewDto(Review review){
//        return new ReviewDTO(review.getReviewRating(), review.getReviewRating(), review.getDescription());
//    }
//    public static Collection<ReviewDto> getFromBooksToBooksDto(List<Review> reviews){
//        List<ReviewDto > reviewDtoList=new ArrayList<>();
//        for (Review review:reviews) {
//           reviewDtoList.add(gerReviewDtoFromReviewDto(review));
//        }
//        return reviewDtoList;/// to be done--------------------
//    }
}
